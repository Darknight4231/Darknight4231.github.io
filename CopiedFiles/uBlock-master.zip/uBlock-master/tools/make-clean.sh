#!/usr/bin/env bash
#
# This script assumes a linux environment

set -e

echo "*** uBlock: Cleaning."
rm -Rf dist/build
echo "*** uBlock: Cleaned."
