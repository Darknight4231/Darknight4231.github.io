# BlurImage
Chrome extension to hide images from Quora (To avoid explicit content)

To use this extension locally 

Download this Repository ZIP.

Go to this link:
https://www.cnet.com/how-to/how-to-install-chrome-extensions-manually

Follow the instruction from step 4
